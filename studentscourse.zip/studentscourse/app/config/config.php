<?php
  // DB Params
  define('DB_HOST', 'localhost');
  define('DB_USER', 'root');
  define('DB_PASS', '7654321aA');
  define('DB_NAME', 'students_course');

  // App Root
  define('APPROOT', dirname(dirname(__FILE__)));
  // URL Root
  define('URLROOT', 'http://localhost/studentscourse/public');
  // Site Name
  define('SITENAME', 'Students Course Managment');
  // App Version
  define('APPVERSION', '1.0.0');